# Redesigning Economist Charts #2
### [Chart #2 data](Economist_2_data.csv)
### Original chart:
![Economist Original 2](Economist_2_original.png)
