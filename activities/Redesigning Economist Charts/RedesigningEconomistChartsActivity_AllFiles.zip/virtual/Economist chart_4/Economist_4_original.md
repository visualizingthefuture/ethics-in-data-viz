# Redesigning Economist Charts #4
### [Chart #4 data](Economist_4_data.csv)
### Original chart:
![Economist Original 4](Economist_4_original.png)
