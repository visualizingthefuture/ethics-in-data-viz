# Redesigning Economist Charts #6
### [Chart #6 data](Economist_6_data.csv)
### Original chart:
![Economist Original 6](Economist_6_original.png)
