# Redesigning Economist Charts #3
### [Chart #3 data](Economist_3_data.csv)
### Original chart
![Economist Original 3](Economist_3_original.png)
