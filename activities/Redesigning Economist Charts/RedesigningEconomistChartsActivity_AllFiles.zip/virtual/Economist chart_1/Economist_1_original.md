# Redesigning Economist Charts #1
### [Chart #1 data](Economist_1_data.csv)
### Original chart:
![Economist Original 1](Economist_1_original.png)
