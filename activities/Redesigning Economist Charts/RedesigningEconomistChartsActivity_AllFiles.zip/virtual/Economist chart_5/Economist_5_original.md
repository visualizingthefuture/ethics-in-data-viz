# Redesigning Economist Charts #5
### [Chart #5 data](Economist_5_data.csv)
### Original chart:
![Economist Original 5](Economist_5_original.png)
