# Mapping Census (ACS) Data
![Poverty Map](img/poverty_original.png)
![Poverty Map, improved context](img/poverty_sex_and_race.png)